<h1>Trabalho de Sistema Distribuidos - Multithreading</h1>

<ol>
    <li>abrir duas janelas direfentes no terminal</li>
    <li>ir para o diretorio onde esta o trabalho, em ambas</li>
    <li>em uma janela, executar python server.py, estando dentro do diretorio do trabalho</li>
    <li>executar python cliente.py em seguida na outra janela</li>
    <li>digitar a mensagem que sera entregue ao server, na janela do cliente</li>
    <li>na janela do servidor, enviar uma mensagem perguntando se sera necessario um novo servico </li>
    <li>na janela do cliente, responda a mensagem do server. Se deseja mais algum servico digite a mensagem, senao aperte a tecla enter para encerrar a conexao</li>
</ol>

